"""
Silver Layer: News RSS
Cleanses and processes news feed data for RAG system
"""
import dlt
from pyspark.sql import functions as F

@dlt.table(
    name="silver_news_rss",
    comment="Cleansed news articles with deduplication for RAG/vector DB"
)
@dlt.expect_or_drop("valid_title", "title IS NOT NULL AND LENGTH(title) > 0")
@dlt.expect_or_drop("valid_link", "link IS NOT NULL")
@dlt.expect("valid_published", "published_timestamp IS NOT NULL")  # [FIX] expect_or_drop → expect (경고만)
def silver_news_rss():
    """
    Processes raw RSS feed data:
    - Converts published timestamp
    - Trims and cleans text fields
    - Deduplicates by link (7-day watermark)
    [FIX] published NULL 처리:
          ingestion에서 published=None 가능 → to_timestamp() 결과도 null
          → coalesce로 ingestion_timestamp fallback 적용, 행 drop 방지
    [FIX] expect_or_drop("valid_published") → expect("valid_published")
          published_timestamp가 null이어도 기사 자체는 유효하므로 drop 불필요
    """
    return (
        dlt.read_stream("bronze_news_rss")
        .select(
            F.trim(F.col("title")).alias("title"),
            F.col("link"),
            # [FIX] published null이면 ingestion_timestamp로 fallback
            F.coalesce(
                F.to_timestamp(F.col("published")),
                F.col("ingestion_timestamp")
            ).alias("published_timestamp"),
            F.trim(F.col("summary")).alias("summary"),
            F.col("source"),
            F.col("ingestion_timestamp")
        )
        .withColumn("text_length", F.length(F.col("summary")))
        .withWatermark("published_timestamp", "7 days")
        .dropDuplicatesWithinWatermark(["link"])
    )