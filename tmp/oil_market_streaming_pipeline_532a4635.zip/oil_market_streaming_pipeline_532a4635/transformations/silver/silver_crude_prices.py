"""
Silver Layer: Crude Oil Prices
Cleanses and transforms crude oil price data with quality checks
"""
import dlt
from pyspark.sql import functions as F

@dlt.table(
    name="silver_crude_prices",
    comment="Cleansed crude oil prices with timestamp normalization and deduplication"
)
@dlt.expect_or_drop("valid_date", "date IS NOT NULL")
@dlt.expect_or_drop("valid_benchmark", "benchmark IS NOT NULL AND benchmark IN ('Dubai', 'Oman', 'Brent', 'WTI', 'Murban')")
@dlt.expect_or_drop("valid_price", "price_usd_bbl IS NOT NULL AND price_usd_bbl >= 0")  # [FIX] > 0 → >= 0
def silver_crude_prices():
    """
    Transforms bronze crude price data:
    - Converts date strings to DATE type
    - Renames columns to match target schema
    - Deduplicates by date and benchmark (7-day watermark)
    [FIX] valid_price: > 0 → >= 0
          proxy 가격(Brent + spread)이 이론상 0에 근접할 수 있음
          원유가격이 음수가 될 수 있는 극단적 시장상황(WTI 2020년 사례) 대응
    """
    return (
        dlt.read_stream("bronze_crude_prices")
        .select(
            F.to_date(F.col("date")).alias("date"),
            F.col("benchmark"),
            F.col("price").cast("double").alias("price_usd_bbl"),
            F.coalesce(F.col("source"), F.lit("FRED")).alias("source"),
            F.col("is_actual_price"),
            F.col("ingestion_timestamp")
        )
        .withWatermark("ingestion_timestamp", "7 days")
        .dropDuplicatesWithinWatermark(["date", "benchmark"])
    )