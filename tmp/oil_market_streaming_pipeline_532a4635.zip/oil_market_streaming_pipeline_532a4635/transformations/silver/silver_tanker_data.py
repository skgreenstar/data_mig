"""
Silver Layer: Tanker Data
Cleanses and transforms tanker logistics data with quality checks
"""
import dlt
from pyspark.sql import functions as F

@dlt.table(
    name="silver_tanker_data",
    comment="Cleansed tanker logistics data with type conversion"
)
@dlt.expect_or_drop("valid_date", "date IS NOT NULL")
@dlt.expect("valid_vlcc_rate", "vlcc_rate_usd_per_day IS NULL OR vlcc_rate_usd_per_day >= 0")
def silver_tanker_data():
    """
    Transforms bronze tanker data:
    - Converts date to DATE type
    - Renames columns to match target schema
    - Deduplicates by date (7-day watermark)
    """
    return (
        dlt.read_stream("bronze_tanker_data")
        .select(
            F.to_date(F.col("date")).alias("date"),
            F.col("vlcc_rate_usd_per_day").cast("double").alias("vlcc_rate_usd_per_day"),
            F.col("floating_storage_mbbl").cast("double").alias("floating_storage_mbbl"),
            F.col("middle_east_loadings_7d_mbd").cast("double").alias("middle_east_loadings_7d_mbd"),
            F.col("ingestion_timestamp")
        )
        .withWatermark("ingestion_timestamp", "7 days")
        .dropDuplicatesWithinWatermark(["date"])
    )