"""
Gold Layer: Market Snapshots (Final Table)
Target schema: main.strategic_ai.market_snapshots
Columns: snapshot_id (STRING), date (DATE), snapshot_time_utc (TIMESTAMP), dxy (DOUBLE), vix (DOUBLE),
         eia_weekly_change_mbbl (DOUBLE), vlcc_rate (DOUBLE),
         price_dubai (DOUBLE), price_oman (DOUBLE), price_brent (DOUBLE),
         price_wti (DOUBLE), price_murban (DOUBLE)

NOTE: Materialized View — Joins all silver tables on date to create historical daily snapshots.
      Uses forward-fill for weekly/sparse data.
"""
import dlt
from pyspark.sql import functions as F
from pyspark.sql.window import Window

@dlt.table(
    name="main.strategic_ai.market_snapshots",
    comment="Consolidated daily market snapshot combining all indicators and crude prices"
)
def market_snapshots():
    """
    Joins all silver tables by date to create historical daily market snapshots.
    Applies forward-fill (last known value) for weekly data like EIA inventory.
    """

    # 1. Crude prices pivot (all benchmarks into columns)
    crude = dlt.read("silver_crude_prices")
    crude_pivoted = (
        crude.groupBy("date")
        .pivot("benchmark", ["Dubai", "Oman", "Brent", "WTI", "Murban"])
        .agg(F.first("price_usd_bbl"))
        .select(
            F.col("date"),
            F.col("Dubai").alias("price_dubai"),
            F.col("Oman").alias("price_oman"),
            F.col("Brent").alias("price_brent"),
            F.col("WTI").alias("price_wti"),
            F.col("Murban").alias("price_murban")
        )
    )

    # 2. Macro indicators
    macro = dlt.read("silver_macro_indicators").select("date", "dxy", "vix")

    # 3. EIA inventory (weekly -> daily expansion)
    eia = dlt.read("silver_eia_inventory").select(
        F.col("report_date").alias("date"),
        F.col("weekly_change_mbbl").alias("eia_weekly_change_mbbl")
    )

    # 4. Tanker data (handle empty table safely)
    tanker = dlt.read("silver_tanker_data").select(
        F.col("date"),
        F.col("vlcc_rate_usd_per_day").alias("vlcc_rate")
    )

    # 5. Union of all dates to ensure no gaps in time series
    all_dates = (
        crude.select("date")
        .union(macro.select("date"))
        .union(eia.select("date"))
        .distinct()
    )

    # 6. Join all metrics on date
    joined = (
        all_dates
        .join(crude_pivoted, "date", "left")
        .join(macro, "date", "left")
        .join(eia, "date", "left")
        .join(tanker, "date", "left")
    )

    # 7. Forward Fill using Window function for sparse metrics
    # last(value, ignoreNulls=True) over window ordered by date
    window_spec = Window.orderBy("date").rowsBetween(Window.unboundedPreceding, 0)
    
    final_df = (
        joined
        .withColumn("eia_weekly_change_mbbl", F.last("eia_weekly_change_mbbl", True).over(window_spec))
        .withColumn("vlcc_rate", F.last("vlcc_rate", True).over(window_spec))
        .withColumn("dxy", F.last("dxy", True).over(window_spec))
        .withColumn("vix", F.last("vix", True).over(window_spec))
        # Add metadata
        .withColumn("snapshot_time_utc", F.current_timestamp())
        .withColumn("snapshot_id", F.concat(
            F.lit("snapshot_"), 
            F.date_format(F.col("date"), "yyyyMMdd"),
            F.lit("_"),
            F.substring(F.expr("uuid()"), 1, 8)
        ))
    )

    return final_df.select(
        "snapshot_id",
        "date",
        "snapshot_time_utc",
        "dxy",
        "vix",
        "eia_weekly_change_mbbl",
        "vlcc_rate",
        "price_dubai",
        "price_oman",
        "price_brent",
        "price_wti",
        "price_murban"
    )