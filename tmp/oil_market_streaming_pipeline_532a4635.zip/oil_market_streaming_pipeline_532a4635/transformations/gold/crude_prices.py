"""
Gold Layer: Crude Prices (Final Table with Auto CDC)
Target schema: main.strategic_ai.crude_prices
Columns: date (DATE, partitioned), benchmark (STRING), price_usd_bbl (DOUBLE), source (STRING)
Uses Auto CDC (SCD Type 1) to UPSERT data - automatically handles duplicates
"""
import dlt

# Step 1: Declare target streaming table
dlt.create_streaming_table(
    name="main.strategic_ai.crude_prices",
    comment="Final crude oil prices table with Auto CDC",
    partition_cols=["date"]
)

# Step 2: Create Auto CDC flow for UPSERT (SCD Type 1)
dlt.apply_changes(
    target="main.strategic_ai.crude_prices",
    source="silver_crude_prices",
    keys=["date", "benchmark"],
    sequence_by="ingestion_timestamp",
    stored_as_scd_type=1
)