"""
Gold Layer: Tanker Data (Final Table with Auto CDC)
Target schema: main.strategic_ai.tanker_data
Columns: date (DATE, partitioned), vlcc_rate_usd_per_day (DOUBLE), 
         floating_storage_mbbl (DOUBLE), middle_east_loadings_7d_mbd (DOUBLE)
Uses Auto CDC (SCD Type 1) to UPSERT data
"""
import dlt

# Step 1: Declare target streaming table
dlt.create_streaming_table(
    name="main.strategic_ai.tanker_data",
    comment="Final tanker logistics table with Auto CDC",
    partition_cols=["date"]
)

# Step 2: Create Auto CDC flow for UPSERT (SCD Type 1)
dlt.apply_changes(
    target="main.strategic_ai.tanker_data",
    source="silver_tanker_data",
    keys=["date"],
    sequence_by="ingestion_timestamp",
    stored_as_scd_type=1
)