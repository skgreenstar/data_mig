"""
Bronze Layer: Macro Indicators
Ingests DXY, KRW/USD, Fed Funds Rate, BoK Base Rate, China PMI, VIX from various APIs
"""
import dlt
from pyspark.sql import functions as F

@dlt.table(
    name="bronze_macro_indicators",
    comment="Raw macro indicators: DXY, KRW/USD, Fed/BoK rates, China PMI (null), VIX"
)
def bronze_macro_indicators():
    """
    Streams JSON files from Unity Catalog Volumes containing macro indicator data
    [FIX] china_manufacturing_pmi → china_pmi (matches ingestion script field name)
          china_pmi is always NULL (FRED series discontinued) — field preserved for schema stability
    Expected JSON fields: date (STRING), dxy (DOUBLE), vix (DOUBLE), krw_usd (DOUBLE),
                         fed_funds_rate (DOUBLE), bok_base_rate (DOUBLE), china_pmi (DOUBLE)
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaHints",
                "date STRING, dxy DOUBLE, vix DOUBLE, krw_usd DOUBLE, "
                "fed_funds_rate DOUBLE, bok_base_rate DOUBLE, china_pmi DOUBLE")
        .load("/Volumes/main/strategic_ai/oil_market_ingestion/macro_indicators/")
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )