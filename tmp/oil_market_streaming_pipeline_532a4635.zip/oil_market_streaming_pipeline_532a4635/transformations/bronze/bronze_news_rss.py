"""
Bronze Layer: News RSS Feed
Ingests oil market news from OilPrice.com and Yahoo Finance RSS feeds
"""
import dlt
from pyspark.sql import functions as F

@dlt.table(
    name="bronze_news_rss",
    comment="Raw RSS news feed: OilPrice.com and Yahoo Finance oil market news"
)
def bronze_news_rss():
    """
    Streams JSON files from Unity Catalog Volumes containing parsed RSS feed data
    Expected JSON fields: title (STRING), link (STRING), published (STRING), summary (STRING), source (STRING)
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaHints", "title STRING, link STRING, published STRING, source STRING, summary STRING")
        .load("/Volumes/main/strategic_ai/oil_market_ingestion/news_rss/")
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )