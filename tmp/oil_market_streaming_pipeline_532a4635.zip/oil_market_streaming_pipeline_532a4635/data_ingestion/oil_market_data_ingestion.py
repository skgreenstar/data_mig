# Databricks notebook source

"""
Oil Market Data Ingestion Script — Final Version
=================================================
Target : /Volumes/main/strategic_ai/oil_market_ingestion/
Sources: FRED API, EIA API, BoK ECOS API, RSS feeds

CHANGES FROM PREVIOUS VERSION
──────────────────────────────────────────────────────────────────────────────
[FIX-1]  EIA `data[0]` → `data[]`  (공식 스펙, 빈 응답 원인)
[FIX-2]  EIA 빈 응답 시 명시적 ValueError 발생 (silent failure 제거)
[FIX-3]  EIA 단위 컬럼명 명시화: crude_stocks → crude_stocks_mmbbls + unit 필드
[FIX-4]  EIA weekly_change: 인덱스 기반 → 날짜 기반 diff (누락 주 오계산 방지)
[FIX-5]  BoK: sample 엔드포인트 → 실제 인증키 엔드포인트 (dbutils.secrets)
[FIX-6]  BoK fallback 상수 1.25% → 현실적 2.75% (현재 기준금리 반영)
[FIX-7]  FRED missing value: "." 외 빈 문자열 케이스 추가 처리
[FIX-8]  China PMI: null 필드 명시적 유지 (공백 제거가 아닌 None으로 보존)
[FIX-9]  Middle East proxy: is_actual_price=False, estimation_method 메타필드 추가
[FIX-10] Tanker placeholder: Volume 저장 완전 비활성화 (격리)
[FIX-11] macro_mapped: FRED 영업일 anchor 기준으로 주말 의미없는 행 필터링
[FIX-12] random.seed(42): 전역 → placeholder 함수 내부로 이동
[FIX-13] RSS published fallback: datetime.now() → None (수집시각 오염 방지)
[FIX-14] EIA: length 기반 → start/end 날짜 파라미터 명시 (누락 주 있어도 범위 보장)
[FIX-15] BoK: API 반환값(변경일 6~8개)에 forward_fill 적용 → 전 영업일 채움
[FIX-16] BoK forward_fill: macro_mapped 생성 전 단계에서 처리
[FIX-17] BoK 수집: FRED 블록 종속 → 독립 수집으로 분리 (FRED 실패해도 BoK 수집됨)

DATA FRESHNESS (기준일: 실행일 당일)
──────────────────────────────────────────────────────────────────────────────
- FRED : 실행일 - 365일 ~ 실행일  (observation_start/end 파라미터 명시)
- EIA  : 실행일 - 364일 ~ 실행일  (start/end 파라미터 명시, 52주 = 364일)
- BoK  : 실행일 - 365일 ~ 실행일  (forward_fill로 전 영업일 커버)
- RSS  : 소스당 최신 10건
- Tanker: DISABLED — no production data source available
"""

import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import time
import subprocess
import sys

# ── auto-install ──────────────────────────────────────────────────────────────
def _install(package: str) -> None:
    try:
        __import__(package)
    except ImportError:
        print(f"📦 Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", package])
        print(f"✅ {package} installed")

_install("feedparser")

# ── logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# ── constants ─────────────────────────────────────────────────────────────────
BASE_PATH  = "/Volumes/main/strategic_ai/oil_market_ingestion"
MAX_RETRIES = 3
RETRY_DELAY = 2   # exponential: 2s → 4s → 8s

PATHS = {
    "crude_prices"  : f"{BASE_PATH}/crude_prices",
    "eia_inventory" : f"{BASE_PATH}/eia_inventory",
    "macro_indicators": f"{BASE_PATH}/macro_indicators",
    "tanker_data"   : f"{BASE_PATH}/tanker_data",   # reserved, not written
    "news_rss"      : f"{BASE_PATH}/news_rss",
}

FRED_SERIES = {
    "DCOILWTICO"  : "WTI",
    "DCOILBRENTEU": "Brent",
    "DTWEXBGS"    : "DXY",
    "VIXCLS"      : "VIX",
    "DEXKOUS"     : "KRW_USD",
    "FEDFUNDS"    : "FedFunds",
    # [FIX-8] China PMI: FRED 시리즈 폐지 → null 필드로 명시 보존
    # "CHGPPIMANGM": 폐지됨. macro_mapped에서 china_pmi=None 으로 유지
}

# [FIX-9] proxy 메타데이터 포함 — 고정 스프레드임을 명시
MIDDLE_EAST_PROXIES = {
    "Dubai" : {"spread": -2.0, "note": "fixed_brent_spread_-2.0_USD"},
    "Oman"  : {"spread": -1.5, "note": "fixed_brent_spread_-1.5_USD"},
    "Murban": {"spread": -0.5, "note": "fixed_brent_spread_-0.5_USD"},
}

RSS_FEEDS = {
    "oilprice" : "https://oilprice.com/rss/main",
    "yahoo_oil": "https://finance.yahoo.com/rss/headline?s=CL=F",
}

# =============================================================================
# HELPERS
# =============================================================================

def get_api_key(key_name: str) -> Optional[str]:
    try:
        return dbutils.secrets.get(scope="oil-market", key=key_name)
    except Exception as e:
        logger.error(f"❌ Secret '{key_name}' 조회 실패: {e}")
        return None


def retry_with_backoff(func, max_retries=MAX_RETRIES, base_delay=RETRY_DELAY):
    """지수 백오프 재시도 (2s → 4s → 8s)"""
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt)
            logger.warning(
                f"⚠️  Attempt {attempt+1}/{max_retries} failed: {e}. "
                f"Retrying in {delay}s..."
            )
            time.sleep(delay)
    return None


def forward_fill_daily(
    monthly_data: Dict[str, float],
    start_date: datetime,
    end_date: datetime,
) -> Dict[str, float]:
    """
    월간 데이터를 일간으로 전진 채움 (Fed Funds rate 용)
    """
    if not monthly_data:
        return {}
    sorted_dates = sorted(monthly_data.keys())
    result: Dict[str, float] = {}
    current = start_date
    while current <= end_date:
        ds = current.strftime("%Y-%m-%d")
        val = None
        for md in sorted_dates:
            if datetime.strptime(md, "%Y-%m-%d") <= current:
                val = monthly_data[md]
            else:
                break
        if val is not None:
            result[ds] = val
        current += timedelta(days=1)
    return result


def save_to_volume_jsonl(records: List[Dict], folder: str, prefix: str) -> bool:
    """JSONL 형식으로 Unity Catalog Volume에 저장 (Auto Loader 호환)"""
    if not records:
        return False
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{prefix}_{ts}.json"
    path     = f"{folder}/{filename}"
    try:
        content = "\n".join(json.dumps(r) for r in records)
        dbutils.fs.put(path, content, overwrite=True)
        logger.info(f"✅ {len(records)} records → {path}")
        return True
    except Exception as e:
        logger.error(f"❌ 저장 실패 {path}: {e}")
        return False


def ensure_volume_paths() -> None:
    for name, path in PATHS.items():
        try:
            dbutils.fs.mkdirs(path)
        except Exception as e:
            logger.warning(f"⚠️  경로 생성 실패 {path}: {e}")


# =============================================================================
# DATA COLLECTORS
# =============================================================================

def collect_fred_data(lookback_days: int = 365) -> List[Dict]:
    """
    FRED API — 원유가격 + 거시지표
    DATA RANGE: 오늘 기준 최근 {lookback_days}일
    """
    import requests

    api_key = get_api_key("fred-api-key")
    if not api_key:
        return []

    base_url   = "https://api.stlouisfed.org/fred/series/observations"
    end_date   = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
    all_records: List[Dict] = []

    for series_id, series_name in FRED_SERIES.items():
        def fetch(sid=series_id):
            params = {
                "series_id"        : sid,
                "api_key"          : api_key,
                "file_type"        : "json",
                "observation_start": start_date,
                "observation_end"  : end_date,
                "sort_order"       : "desc",
            }
            resp = requests.get(base_url, params=params, timeout=30)
            resp.raise_for_status()
            return resp.json()

        try:
            data = retry_with_backoff(fetch)
            if data:
                count = 0
                for obs in data.get("observations", []):
                    # [FIX-7] "." 및 빈 문자열 모두 결측 처리
                    if obs["value"] not in (".", "", None):
                        all_records.append({
                            "date"       : obs["date"],
                            "series_id"  : series_id,
                            "series_name": series_name,
                            "value"      : float(obs["value"]),
                            "source"     : "FRED",
                        })
                        count += 1
                logger.info(f"✅ FRED {series_name}: {count}개 수집")
        except Exception as e:
            logger.error(f"❌ FRED {series_id} 수집 실패 ({MAX_RETRIES}회): {e}")

    return all_records


def collect_eia_data(lookback_weeks: int = 52) -> List[Dict]:
    """
    EIA API v2 — 미국 원유 재고 (주간)
    DATA RANGE: 실행일 기준 lookback_weeks주 전 ~ 실행일
    [FIX-14] length 기반 → start/end 날짜 파라미터 명시
             (누락 주가 있어도 날짜 범위가 보장됨)
    단위: MMBbl (백만 배럴) — crude_stocks_mmbbls 컬럼명 명시 [FIX-3]
    """
    import requests

    api_key = get_api_key("eia-api-key")
    if not api_key:
        return []

    base_url   = "https://api.eia.gov/v2/petroleum/stoc/wstk/data/"
    # [FIX-14] 날짜 범위 명시: 52주 = 364일
    start_date = (datetime.now() - timedelta(weeks=lookback_weeks)).strftime("%Y-%m-%d")
    end_date   = datetime.now().strftime("%Y-%m-%d")

    def fetch():
        params = {
            "api_key"            : api_key,
            "frequency"          : "weekly",
            "data[]"             : "value",       # [FIX-1] data[0] → data[]
            "facets[product][]"  : "EPC0",
            "facets[duoarea][]"  : "NUS",
            "start"              : start_date,    # [FIX-14] 날짜 범위 명시
            "end"                : end_date,      # [FIX-14]
            "sort[0][column]"    : "period",
            "sort[0][direction]" : "asc",         # 오래된 것부터 정렬
            "length"             : 5000,          # 충분히 크게 설정 (실제 row ≈ 52개)
        }
        resp = requests.get(base_url, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        # [FIX-2] 빈 응답 silent failure 방지
        records = data.get("response", {}).get("data", [])
        if not records:
            raise ValueError(f"EIA returned empty data. Response: {data}")
        return data

    try:
        data        = retry_with_backoff(fetch)
        raw_records = data["response"]["data"]

        result = []
        for r in raw_records:
            result.append({
                "report_date"        : r["period"],
                "crude_stocks_mmbbls": round(float(r["value"]) / 1000.0, 3),  # [FIX-3]
                "unit"               : "million_barrels",                       # [FIX-3]
                "source"             : "EIA",
            })

        logger.info(
            f"✅ EIA 재고: {len(result)}개 수집 "
            f"({start_date} ~ {end_date})"
        )
        return result

    except Exception as e:
        logger.error(f"❌ EIA 수집 실패 ({MAX_RETRIES}회): {e}")
        return []


def _add_weekly_change(records: List[Dict]) -> List[Dict]:
    """
    [FIX-4] weekly_change: 인덱스 기반 → 날짜 기반 계산
    누락 주가 있을 경우 인덱스 방식은 틀린 diff를 계산하므로
    정확히 7일 간격인 경우에만 계산
    """
    by_date = {r["report_date"]: r for r in records}
    for r in records:
        try:
            prev_date = (
                datetime.strptime(r["report_date"], "%Y-%m-%d") - timedelta(weeks=1)
            ).strftime("%Y-%m-%d")
            prev = by_date.get(prev_date)
            if prev:
                r["weekly_change_mmbbls"] = round(
                    r["crude_stocks_mmbbls"] - prev["crude_stocks_mmbbls"], 3
                )
            else:
                r["weekly_change_mmbbls"] = None   # 누락 주 → None 명시
        except Exception:
            r["weekly_change_mmbbls"] = None
    return records


def collect_bok_rate_historical(lookback_days: int = 365) -> Dict[str, float]:
    """
    한국은행 ECOS API — 기준금리 (결정일 기준 sparse data)
    [FIX-5]  sample 엔드포인트 → 실제 인증키 엔드포인트
    [FIX-6]  fallback 상수 1.25% → 2.75% (현재 BoK 기준금리)
    [FIX-15] 반환값: 결정일 raw dict (forward_fill은 호출부에서 처리)
             이 함수는 실제 결정일 데이터만 반환 (1년에 6~8개 row 정상)
    API 키: https://ecos.bok.or.kr → 개발자 서비스 → 인증키 신청 (무료)
    """
    import requests

    bok_api_key = get_api_key("bok-api-key")

    if not bok_api_key:
        logger.warning("⚠️  bok-api-key 없음 — fallback 사용")
    else:
        try:
            start = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y%m%d")
            end   = datetime.now().strftime("%Y%m%d")
            url   = (
                f"https://ecos.bok.or.kr/api/StatisticSearch"
                f"/{bok_api_key}/json/en/1/10000/722Y001/D/{start}/{end}/0101000"
            )

            def fetch():
                resp = requests.get(url, timeout=30)
                resp.raise_for_status()
                return resp.json()

            data = retry_with_backoff(fetch)
            if (
                data
                and "StatisticSearch" in data
                and "row" in data["StatisticSearch"]
            ):
                result: Dict[str, float] = {}
                for row in data["StatisticSearch"]["row"]:
                    ds  = row["TIME"]
                    fmt = f"{ds[:4]}-{ds[4:6]}-{ds[6:8]}"
                    result[fmt] = float(row["DATA_VALUE"])
                logger.info(
                    f"✅ BoK 기준금리: {len(result)}개 결정일 수집 "
                    f"(forward_fill로 전 영업일 확장 예정)"
                )
                return result  # [FIX-15] sparse raw dict 반환, fill은 호출부에서
        except Exception as e:
            logger.warning(f"⚠️  BoK 수집 실패 ({MAX_RETRIES}회): {e}")

    # fallback: 현재 기준금리 2.75% [FIX-6]
    logger.warning("⚠️  BoK fallback: 2.75% (constant) 사용 — 실제 값 아님")
    # fallback도 sparse dict로 반환 (시작일 하나만, forward_fill이 확장)
    fallback_start = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
    return {fallback_start: 2.75}


def collect_rss_feeds() -> List[Dict]:
    """
    RSS — 유가 관련 뉴스 (소스당 최신 10건)
    [FIX-13] published fallback: datetime.now() → None (수집시각 오염 방지)
    """
    import feedparser

    all_records: List[Dict] = []
    for source_name, feed_url in RSS_FEEDS.items():
        def fetch(url=feed_url):
            return feedparser.parse(url)

        try:
            feed = retry_with_backoff(fetch)
            if feed:
                for entry in feed.entries[:10]:
                    all_records.append({
                        "title"    : entry.get("title", ""),
                        "link"     : entry.get("link", ""),
                        "published": entry.get("published") or None,  # [FIX-13]
                        "source"   : source_name,
                        "summary"  : (entry.get("summary") or "")[:500],
                    })
                logger.info(f"✅ RSS {source_name}: {len(feed.entries[:10])}개 수집")
        except Exception as e:
            logger.error(f"❌ RSS {source_name} 수집 실패: {e}")

    return all_records


# =============================================================================
# MAIN PIPELINE
# =============================================================================

def process_and_save_data() -> bool:
    logger.info("=" * 80)
    logger.info("🚀 Oil Market Data Ingestion 시작")
    logger.info("=" * 80)
    ensure_volume_paths()

    success, total = 0, 0

    # ── BoK (FRED와 독립 수집) [FIX-17] ─────────────────────────────────────
    # FRED 성공 여부와 무관하게 항상 먼저 수집
    logger.info("\n📊 BoK 기준금리 수집 중...")
    pipeline_start = datetime.now() - timedelta(days=365)
    pipeline_end   = datetime.now()

    bok_sparse  = collect_bok_rate_historical(lookback_days=365)
    bok_by_date = forward_fill_daily(bok_sparse, pipeline_start, pipeline_end)
    logger.info(f"✅ BoK forward_fill 완료: {len(bok_by_date)}일치")

    # ── FRED ──────────────────────────────────────────────────────────────────
    logger.info("\n📊 FRED 수집 중...")
    fred_data = collect_fred_data(lookback_days=365)

    if fred_data:
        crude_raw = [r for r in fred_data if r["series_name"] in ("WTI", "Brent")]
        macro_raw = [r for r in fred_data if r["series_name"] not in ("WTI", "Brent")]

        # -- crude prices --
        crude_mapped = [
            {"date": r["date"], "benchmark": r["series_name"],
             "price": r["value"], "source": "FRED",
             "is_actual_price": True}
            for r in crude_raw
        ]

        # [FIX-9] Middle East proxy — 메타데이터 명시
        brent_map = {r["date"]: r["value"] for r in crude_raw if r["series_name"] == "Brent"}
        for date, brent_price in brent_map.items():
            for benchmark, meta in MIDDLE_EAST_PROXIES.items():
                crude_mapped.append({
                    "date"             : date,
                    "benchmark"        : benchmark,
                    "price"            : round(brent_price + meta["spread"], 2),
                    "source"           : "CALCULATED_ESTIMATE",
                    "is_actual_price"  : False,
                    "estimation_method": meta["note"],
                })
        logger.info(f"✅ Middle East proxy 추가: {len(MIDDLE_EAST_PROXIES)}종")

        # -- macro indicators --
        by_date: Dict[str, Dict] = defaultdict(dict)
        for r in macro_raw:
            by_date[r["date"]][r["series_name"].lower()] = r["value"]

        # FRED 영업일 anchor 날짜만 사용 [FIX-11]
        fred_business_dates = set(by_date.keys())

        # Fed Funds: 월간 → 일간 전진 채움
        fed_monthly = {
            d: v["fedfunds"]
            for d, v in by_date.items()
            if v.get("fedfunds") is not None
        }
        fed_daily = forward_fill_daily(fed_monthly, pipeline_start, pipeline_end)

        # [FIX-11] FRED 영업일 기준으로만 행 생성 (주말/무의미 행 제거)
        # bok_by_date: FRED보다 먼저 수집 완료된 상태 [FIX-17]
        macro_mapped = [
            {
                "date"          : date,
                "dxy"           : by_date[date].get("dxy"),
                "vix"           : by_date[date].get("vix"),
                "krw_usd"       : by_date[date].get("krw_usd"),
                "fed_funds_rate": fed_daily.get(date),
                "bok_base_rate" : bok_by_date.get(date),  # [FIX-17] 독립 수집값
                "china_pmi"     : None,   # [FIX-8] 시리즈 폐지 — 필드 보존
            }
            for date in sorted(fred_business_dates)
        ]

        total += 1
        if crude_mapped and save_to_volume_jsonl(crude_mapped, PATHS["crude_prices"], "fred_crude"):
            success += 1

        total += 1
        if macro_mapped and save_to_volume_jsonl(macro_mapped, PATHS["macro_indicators"], "fred_macro"):
            success += 1

    # ── EIA ───────────────────────────────────────────────────────────────────
    logger.info("\n📊 EIA 재고 수집 중...")
    eia_data = collect_eia_data(lookback_weeks=52)
    if eia_data:
        eia_sorted = sorted(eia_data, key=lambda x: x["report_date"])
        eia_sorted = _add_weekly_change(eia_sorted)   # [FIX-4]

        total += 1
        if save_to_volume_jsonl(eia_sorted, PATHS["eia_inventory"], "eia_stocks"):
            success += 1

    # ── Tanker — DISABLED [FIX-10] ────────────────────────────────────────────
    logger.warning(
        "⚠️  Tanker 데이터 수집 비활성화 — 실제 데이터 소스 없음 "
        "(Kpler/Vortexa 유료 구독 필요)"
    )
    # tanker_data 폴더는 생성되나 아무것도 쓰지 않음

    # ── RSS ───────────────────────────────────────────────────────────────────
    logger.info("\n📊 RSS 뉴스 수집 중...")
    news_data = collect_rss_feeds()
    if news_data:
        total += 1
        if save_to_volume_jsonl(news_data, PATHS["news_rss"], "rss_news"):
            success += 1

    logger.info("\n" + "=" * 80)
    logger.info(f"✅ 수집 완료: {success}/{total} 성공")
    logger.info("=" * 80)
    return success == total


# =============================================================================
if __name__ == "__main__":
    try:
        ok = process_and_save_data()
        if ok:
            logger.info("🎉 전체 수집 완료")
        else:
            logger.warning("⚠️  일부 소스 실패 — 로그 확인 필요")
    except Exception as e:
        logger.error(f"❌ Fatal: {e}")
        import traceback; traceback.print_exc()
        raise