"""
Bronze Layer: Crude Oil Prices
Ingests WTI, Brent, Dubai, Oman, Murban prices from FRED API via Unity Catalog Volumes
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

@dp.table(
    name="bronze_crude_prices",
    comment="Raw crude oil prices from FRED API (WTI, Brent, Dubai, Oman, Murban)"
)
def bronze_crude_prices():
    """
    Streams JSON files from Unity Catalog Volumes containing FRED API responses
    Expected JSON fields: date (STRING), benchmark (STRING), price (DOUBLE), source (STRING)
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaHints", "date STRING, benchmark STRING, price DOUBLE, source STRING")
        .load("/Volumes/main/strategic_ai/oil_market_ingestion/crude_prices/")
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )
