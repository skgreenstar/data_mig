"""
Bronze Layer: Tanker & Logistics Data
Ingests VLCC rates, floating storage, Middle East loading volumes
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

@dp.table(
    name="bronze_tanker_data",
    comment="Raw tanker logistics data: VLCC rates, floating storage, ME loadings"
)
def bronze_tanker_data():
    """
    Streams JSON files from Unity Catalog Volumes containing tanker logistics data
    Expected JSON fields: date (STRING), vlcc_rate (DOUBLE), floating_storage (DOUBLE), 
                         middle_east_loadings_7d (DOUBLE)
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaHints", "date STRING, vlcc_rate_usd_per_day DOUBLE, floating_storage_mbbl DOUBLE, middle_east_loadings_7d_mbd DOUBLE, source STRING")
        .load("/Volumes/main/strategic_ai/oil_market_ingestion/tanker_data/")
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )