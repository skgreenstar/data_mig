"""
Bronze Layer: EIA Inventory Data
Ingests US crude oil inventory data from EIA API via Unity Catalog Volumes
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

@dp.table(
    name="bronze_eia_inventory",
    comment="Raw EIA crude oil inventory data (weekly stocks in MMBbl, weekly change)"
)
def bronze_eia_inventory():
    """
    Streams JSON files from Unity Catalog Volumes containing EIA API responses
    [FIX] schemaHints updated to match ingestion script output:
          crude_stocks_mmbbls (was crude_stocks)
          weekly_change_mmbbls (was weekly_change)
          oecd_total removed (not collected)
          unit added (million_barrels)
    Expected JSON fields: report_date (STRING), crude_stocks_mmbbls (DOUBLE),
                         weekly_change_mmbbls (DOUBLE), unit (STRING), source (STRING)
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaHints",
                "report_date STRING, crude_stocks_mmbbls DOUBLE, "
                "weekly_change_mmbbls DOUBLE, unit STRING, source STRING")
        .load("/Volumes/main/strategic_ai/oil_market_ingestion/eia_inventory/")
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )