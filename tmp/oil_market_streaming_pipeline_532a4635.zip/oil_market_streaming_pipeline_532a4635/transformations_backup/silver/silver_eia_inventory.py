"""
Silver Layer: EIA Inventory
Cleanses and transforms EIA inventory data with quality checks
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

@dp.table(
    name="silver_eia_inventory",
    comment="Cleansed EIA inventory data with type conversion and deduplication"
)
@dp.expect_or_drop("valid_report_date", "report_date IS NOT NULL")
@dp.expect_or_drop("valid_stocks", "crude_stocks_mbbl IS NOT NULL AND crude_stocks_mbbl >= 0")
def silver_eia_inventory():
    """
    Transforms bronze EIA inventory data:
    - Converts report_date to DATE type
    - Renames columns to match target schema
    - Deduplicates by report_date (365-day watermark for historical backfill)
    - Handles both crude_stocks and crude_stocks_mmbbls columns (legacy + new format)
    [FIX] crude_stocks → crude_stocks_mmbbls (matches ingestion script)
    [FIX] weekly_change → weekly_change_mmbbls (matches ingestion script)
    [FIX] oecd_total removed (not collected by ingestion — was always NULL)
    [FIX] COALESCE for backward compatibility with old column names
    """
    return (
        spark.readStream.table("bronze_eia_inventory")
        .select(
            F.to_date(F.col("report_date")).alias("report_date"),
            F.coalesce(
                F.col("crude_stocks_mmbbls"),
                F.col("crude_stocks")
            ).cast("double").alias("crude_stocks_mbbl"),
            F.coalesce(
                F.col("weekly_change_mmbbls"),
                F.col("weekly_change")
            ).cast("double").alias("weekly_change_mbbl"),
            F.col("ingestion_timestamp")
        )
        .withWatermark("ingestion_timestamp", "365 days")
        .dropDuplicatesWithinWatermark(["report_date"])
    )