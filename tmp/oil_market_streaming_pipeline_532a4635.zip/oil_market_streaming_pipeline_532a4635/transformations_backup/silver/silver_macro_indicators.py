"""
Silver Layer: Macro Indicators
Cleanses and transforms macro indicator data with quality checks
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

@dp.table(
    name="silver_macro_indicators",
    comment="Cleansed macro indicators with timestamp normalization"
)
@dp.expect_or_drop("valid_date", "date IS NOT NULL")
@dp.expect("valid_dxy", "dxy IS NULL OR dxy > 0")
@dp.expect("valid_vix", "vix IS NULL OR vix >= 0")
def silver_macro_indicators():
    """
    Transforms bronze macro indicator data:
    - Converts date to DATE type
    - Ensures all numeric fields are DOUBLE
    - Deduplicates by date (7-day watermark)
    [FIX] china_manufacturing_pmi → china_pmi (matches ingestion + bronze field name)
          china_pmi is always NULL (FRED series discontinued) — preserved for schema stability
    """
    return (
        spark.readStream.table("bronze_macro_indicators")
        .select(
            F.to_date(F.col("date")).alias("date"),
            F.col("dxy").cast("double"),
            F.col("krw_usd").cast("double"),
            F.col("fed_funds_rate").cast("double"),
            F.col("bok_base_rate").cast("double"),
            F.col("china_pmi").cast("double"),          # always NULL — schema preserved
            F.col("vix").cast("double"),
            F.col("ingestion_timestamp")
        )
        .withWatermark("ingestion_timestamp", "7 days")
        .dropDuplicatesWithinWatermark(["date"])
    )