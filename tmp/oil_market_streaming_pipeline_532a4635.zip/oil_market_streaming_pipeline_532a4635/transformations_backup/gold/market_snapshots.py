"""
Gold Layer: Market Snapshots (Final Table)
Target schema: main.strategic_ai.market_snapshots
Columns: snapshot_id (STRING), snapshot_time_utc (TIMESTAMP), dxy (DOUBLE), vix (DOUBLE),
         eia_weekly_change_mbbl (DOUBLE), vlcc_rate (DOUBLE),
         price_dubai (DOUBLE), price_oman (DOUBLE), price_brent (DOUBLE),
         price_wti (DOUBLE), price_murban (DOUBLE)

NOTE: Materialized View — 파이프라인 실행마다 새 snapshot row 추가.
      Silver 테이블에서 읽어 circular dependency 방지.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.window import Window

@dp.table(
    name="main.strategic_ai.market_snapshots",
    comment="Consolidated market snapshot combining all indicators and crude prices"
)
def market_snapshots():
    """
    Joins all silver tables to create unified market snapshot.
    Takes latest available data for each indicator.
    Each pipeline run creates a new snapshot row.

    [FIX] tanker crossJoin: silver_tanker_data 비어있으면 전체 결과 0행 문제 수정
          → tanker 데이터 없을 경우 vlcc_rate=NULL로 안전하게 처리
    """

    # ── macro (latest 1 row) ──────────────────────────────────────────────────
    macro_latest = (
        spark.read.table("silver_macro_indicators")
        .orderBy(F.col("date").desc())
        .limit(1)
        .select("dxy", "vix")
    )

    # ── EIA inventory (latest 1 row) ──────────────────────────────────────────
    eia_latest = (
        spark.read.table("silver_eia_inventory")
        .orderBy(F.col("report_date").desc())
        .limit(1)
        .select(F.col("weekly_change_mbbl").alias("eia_weekly_change_mbbl"))
    )

    # ── Tanker (latest 1 row, NULL-safe) ──────────────────────────────────────
    # [FIX] Tanker 비활성화 상태 → 데이터 없으면 vlcc_rate=NULL 행 생성
    #       crossJoin 시 0행 문제 방지
    tanker_raw = (
        spark.read.table("silver_tanker_data")
        .orderBy(F.col("date").desc())
        .limit(1)
        .select(F.col("vlcc_rate_usd_per_day").alias("vlcc_rate"))
    )
    tanker_latest = (
        tanker_raw
        if tanker_raw.count() > 0
        else spark.createDataFrame([(None,)], "vlcc_rate DOUBLE")
    )

    # ── Crude prices pivot (latest per benchmark) ─────────────────────────────
    crude_window = Window.partitionBy("benchmark").orderBy(F.col("date").desc())

    crude_pivoted = (
        spark.read.table("silver_crude_prices")
        .withColumn("row_num", F.row_number().over(crude_window))
        .filter(F.col("row_num") == 1)
        .groupBy()
        .pivot("benchmark", ["Dubai", "Oman", "Brent", "WTI", "Murban"])
        .agg(F.first("price_usd_bbl"))
        .select(
            F.col("Dubai").alias("price_dubai"),
            F.col("Oman").alias("price_oman"),
            F.col("Brent").alias("price_brent"),
            F.col("WTI").alias("price_wti"),
            F.col("Murban").alias("price_murban")
        )
    )

    # ── Assemble snapshot ─────────────────────────────────────────────────────
    snapshot_time = F.current_timestamp()

    return (
        macro_latest
        .crossJoin(eia_latest)
        .crossJoin(tanker_latest)
        .crossJoin(crude_pivoted)
        .withColumn("snapshot_time_utc", snapshot_time)
        .withColumn("snapshot_id", F.concat(
            F.lit("snapshot_"),
            F.date_format(snapshot_time, "yyyyMMddHHmmss"),
            F.lit("_"),
            F.expr("uuid()")
        ))
        .select(
            "snapshot_id",
            "snapshot_time_utc",
            "dxy",
            "vix",
            "eia_weekly_change_mbbl",
            "vlcc_rate",
            "price_dubai",
            "price_oman",
            "price_brent",
            "price_wti",
            "price_murban"
        )
    )