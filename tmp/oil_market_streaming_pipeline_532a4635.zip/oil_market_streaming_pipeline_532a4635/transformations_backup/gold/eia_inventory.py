"""
Gold Layer: EIA Inventory (Final Table with Recalculated Weekly Change)
Target schema: main.strategic_ai.eia_inventory
Columns: report_date (DATE), crude_stocks_mbbl (DOUBLE), weekly_change_mbbl (DOUBLE)
Uses Materialized View to recalculate weekly_change from crude_stocks
[FIX] oecd_total_mbbl 컬럼 제거 (ingestion에서 미수집, 항상 NULL이었음)
[FIX] weekly_change_mbbl을 Silver의 값 대신 LAG()로 재계산하여 NULL 제거
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.window import Window

@dp.materialized_view(
    name="main.strategic_ai.eia_inventory",
    comment="Final EIA crude oil inventory table with recalculated weekly change"
)
def eia_inventory():
    """
    Recalculates weekly_change_mbbl using LAG window function.
    This ensures that weekly_change is correctly calculated even when
    Bronze data has inconsistent weekly_change values.
    """
    # Define window partitioned by report_date, ordered by report_date
    window_spec = Window.orderBy("report_date")
    
    return (
        spark.read.table("silver_eia_inventory")
        .select(
            F.col("report_date"),
            F.col("crude_stocks_mbbl"),
            F.col("ingestion_timestamp")
        )
        # Calculate weekly change as current stocks - previous week stocks
        .withColumn(
            "weekly_change_mbbl",
            F.col("crude_stocks_mbbl") - F.lag(F.col("crude_stocks_mbbl"), 1).over(window_spec)
        )
        .select(
            "report_date",
            "crude_stocks_mbbl",
            "weekly_change_mbbl",
            "ingestion_timestamp"
        )
    )