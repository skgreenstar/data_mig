"""
Gold Layer: Macro Indicators (Final Table with Auto CDC)
Target schema: main.strategic_ai.macro_indicators
Columns: date (DATE, partitioned), dxy (DOUBLE), vix (DOUBLE), krw_usd (DOUBLE),
         fed_funds_rate (DOUBLE), bok_base_rate (DOUBLE), china_pmi (DOUBLE)
Uses Auto CDC (SCD Type 1) to UPSERT data — automatically handles duplicates
[FIX] china_manufacturing_pmi → china_pmi (ingestion/bronze/silver 전 레이어 통일)
"""
from pyspark import pipelines as dp

# Step 1: Declare target streaming table
dp.create_streaming_table(
    name="main.strategic_ai.macro_indicators",
    comment="Final macro indicators table with Auto CDC",
    partition_cols=["date"]
)

# Step 2: Create Auto CDC flow for UPSERT
dp.create_auto_cdc_flow(
    target="main.strategic_ai.macro_indicators",
    source="silver_macro_indicators",
    keys=["date"],
    sequence_by="ingestion_timestamp",
    stored_as_scd_type=1
)